from fastapi import FastAPI, File, UploadFile, Request
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import sqlite3
import pandas as pd
from io import BytesIO
import subprocess
import matplotlib.pyplot as plt
import os

app = FastAPI()

DB_PATH = "product_insights.db"
CHART_PATH = "static/chart.png"

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def serve_home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

def save_excel_to_sqlite(files: dict):
    conn = sqlite3.connect(DB_PATH)
    for name, file in files.items():
        df = pd.read_excel(BytesIO(file))
        df.to_sql(name, conn, if_exists="replace", index=False)
    conn.close()

def get_db_schema():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    schema = ""
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    for row in cursor.fetchall():
        table = row[0]
        schema += f"\nTable: {table}\nColumns:\n"
        cursor.execute(f"PRAGMA table_info({table});")
        for col in cursor.fetchall():
            schema += f"  - {col[1]} ({col[2]})\n"
    conn.close()
    return schema

def ask_mistral(prompt: str) -> str:
    result = subprocess.run(
        ["ollama", "run", "mistral", prompt],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace"
    )
    return result.stdout.strip()

def run_sql_query(sql_query: str) -> pd.DataFrame:
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql_query(sql_query, conn)
    conn.close()
    return df

def try_generate_chart(df: pd.DataFrame) -> str:
    try:
        if df.shape[1] >= 2:
            x, y = df.columns[0], df.columns[1]
            plt.figure(figsize=(8, 5))
            df.plot(kind="bar", x=x, y=y, legend=False)
            plt.xlabel(x)
            plt.ylabel(y)
            plt.title(f"{y} by {x}")
            plt.tight_layout()
            plt.savefig(CHART_PATH)
            return CHART_PATH
    except:
        pass
    return None

@app.post("/upload/")
async def upload_files(
    ad_sales: UploadFile = File(...),
    total_sales: UploadFile = File(...),
    eligibility: UploadFile = File(...)
):
    files = {
        "ad_sales": await ad_sales.read(),
        "total_sales": await total_sales.read(),
        "eligibility": await eligibility.read()
    }
    save_excel_to_sqlite(files)
    return {"message": "✅ Files uploaded and SQL tables created."}

class QuestionRequest(BaseModel):
    question: str

@app.post("/ask/")
def ask_question(req: QuestionRequest):
    schema = get_db_schema()
    user_q = req.question
    sql_prompt = f"""You are a helpful assistant that writes SQL queries based on user questions.

Here is the database schema:
{schema}

Question: {user_q}
Write only the SQL query. Do not explain anything."""
    sql = ask_mistral(sql_prompt)

    try:
        result_df = run_sql_query(sql)
        result_json = result_df.to_dict(orient="records")
        result_str = result_df.to_string(index=False)
    except Exception as e:
        return {"sql": sql, "error": str(e)}

    explanation_prompt = f"""You are a helpful assistant. A user asked: "{user_q}"

Here is the SQL query that was used to answer it:
{sql}

Here is the result of the query:
{result_str}

Now explain this result in a simple, human-readable way. Respond as if you are talking to a non-technical user."""
    explanation = ask_mistral(explanation_prompt)

    chart_path = try_generate_chart(result_df)
    return {
        "question": user_q,
        "sql": sql,
        "natural_language_answer": explanation,
        "raw_table_result": result_json,
        "chart_url": f"/chart" if chart_path else None
    }

@app.get("/chart")
def get_chart():
    if os.path.exists(CHART_PATH):
        return FileResponse(CHART_PATH, media_type="image/png")
    return JSONResponse({"error": "Chart not available"}, status_code=404)